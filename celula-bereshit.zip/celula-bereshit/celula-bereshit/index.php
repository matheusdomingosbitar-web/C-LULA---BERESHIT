<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Célula Bereshit</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <h1>💙 Célula Bereshit 💙</h1>
  <p>IAAP Vila Matilde</p>
</header>
<nav>
  <a href="avisos.php">Avisos</a>
  <a href="agenda.php">Agenda</a>
  <a href="anotacoes.php">Anotações</a>
  <a href="entrar.php">Entrar</a>
  <a href="admin/index.php">Admin</a>
</nav>
<section>
  <h2>Bem-vindo</h2>
  <p>Participe das atividades da nossa célula!</p>
</section>
<footer>
  <p>© 2024 Célula Bereshit</p>
</footer>
</body>
</html>