<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Agenda - Célula Bereshit</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <h1>📆 Agenda</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <a href="avisos.php">Avisos</a>
  <a href="agenda.php">Agenda</a>
  <a href="anotacoes.php">Anotações</a>
</nav>
<section>
<?php
$stmt = $conn->query("SELECT * FROM agenda ORDER BY data_evento ASC");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<div class='card'>
            <h3>{$row['evento']}</h3>
            <p>Data: " . date("d/m/Y", strtotime($row['data_evento'])) . "</p>
         </div>";
}
?>
</section>
</body>
</html>