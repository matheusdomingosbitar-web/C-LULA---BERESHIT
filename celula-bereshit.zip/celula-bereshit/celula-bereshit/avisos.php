<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Avisos - Célula Bereshit</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <h1>📢 Avisos</h1>
</header>
<nav>
  <a href="index.php">Início</a>
  <a href="agenda.php">Agenda</a>
  <a href="anotacoes.php">Anotações</a>
  <a href="entrar.php">Entrar</a>
</nav>
<section>
<?php
$stmt = $conn->query("SELECT * FROM avisos ORDER BY data DESC");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<div class='card'>";
    echo "<h3>" . htmlspecialchars($row['titulo']) . "</h3>";
    echo "<p>" . nl2br(htmlspecialchars($row['mensagem'])) . "</p>";
    echo "<small>Data: " . $row['data'] . "</small>";
    echo "</div>";
}
?>
</section>
<footer>
  <p>© 2024 Célula Bereshit</p>
</footer>
</body>
</html>