<?php include 'config.php'; ?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conteudo = $_POST['conteudo'];
    $stmt = $conn->prepare("INSERT INTO anotacoes (conteudo) VALUES (?)");
    $stmt->execute([$conteudo]);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Anotações - Célula Bereshit</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
  <h1>✏️ Anotações</h1>
</header>
<nav>
  <a href="index.php">Home</a>
  <a href="avisos.php">Avisos</a>
  <a href="agenda.php">Agenda</a>
  <a href="anotacoes.php">Anotações</a>
</nav>
<section>
<form method="POST">
    <textarea name="conteudo" rows="5" placeholder="Escreva sua anotação"></textarea>
    <input type="submit" value="Salvar Anotação">
</form>
<hr>
<?php
$stmt = $conn->query("SELECT * FROM anotacoes ORDER BY data DESC");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<div class='card'><p>{$row['conteudo']}</p><small>" . date("d/m/Y H:i", strtotime($row['data'])) . "</small></div>";
}
?>
</section>
</body>
</html>