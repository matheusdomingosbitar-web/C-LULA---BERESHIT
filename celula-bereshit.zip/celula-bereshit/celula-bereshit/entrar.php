<?php include 'config.php'; ?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("INSERT INTO membros (nome, email) VALUES (?, ?)");
    $stmt->execute([$nome, $email]);
    echo "<script>alert('Solicitação enviada! Aguarde aprovação.');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Entrar na Célula</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<h2>Solicitar entrada</h2>
<form method="POST">
    <label>Nome:</label><br>
    <input type="text" name="nome" required><br>
    <label>Email:</label><br>
    <input type="email" name="email" required><br>
    <input type="submit" value="Enviar Solicitação">
</form>
</body>
</html>