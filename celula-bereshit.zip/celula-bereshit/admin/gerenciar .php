<?php
session_start();
include '../config.php';
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['tipo']) && $_POST['tipo'] == 'aviso') {
        $stmt = $conn->prepare("INSERT INTO avisos (titulo, mensagem) VALUES (?, ?)");
        $stmt->execute([$_POST['titulo'], $_POST['mensagem']]);
    }
    if (isset($_POST['tipo']) && $_POST['tipo'] == 'agenda') {\n        $stmt = $conn->prepare("INSERT INTO agenda (evento, data_evento) VALUES (?, ?)");
        $stmt->execute([$_POST['evento'], $_POST['data_evento']]);
    }
    if (isset($_POST['tipo']) && $_POST['tipo'] == 'anotacao') {
        $stmt = $conn->prepare("INSERT INTO anotacoes (conteudo) VALUES (?)");
        $stmt->execute([$_POST['conteudo']]);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Gerenciar Conteúdo</title>
<link rel="stylesheet" href="../css style.css">
</head>
<body>
<h2>Adicionar Aviso</h2>
<form method="POST">
    <input type="hidden" name="tipo" value="aviso">
    <input type="text" name="titulo" placeholder="Título" required>
    <textarea name="mensagem" placeholder="Mensagem" required></textarea>
    <input type="submit" value="Adicionar">
</form>

<h2>Adicionar Evento na Agenda</h2>
<form method="POST">
    <input type="hidden" name="tipo" value="agenda">
    <input type="text" name="evento" placeholder="Evento" required>
    <input type="date" name="data_evento" required>
    <input type="submit" value="Adicionar">
</form>

<h2>Adicionar Anotação</h2>
<form method="POST">
    <input type="hidden" name="tipo" value="anotacao">
    <textarea name="conteudo" placeholder="Anotação" required></textarea>
    <input type="submit" value="Adicionar">
</form>
</body>
</html>