<?php
session_start();
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $senha = md5($_POST['senha']); // criptografa

    $stmt = $conn->prepare("SELECT * FROM admin WHERE usuario = ? AND senha = ?");
    $stmt->execute([$usuario, $senha]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['admin'] = $usuario;
        header("Location: dashboard.php");
        exit;
    } else {
        echo "<script>alert('Usuário ou senha incorretos!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Login Administrador</title>
<link rel="stylesheet" href="../css style.css">
</head>
<body>
<h2>Login do Admin</h2>
<form method="POST">
    <label>Usuário:</label>
    <input type="text" name="usuario" required>
    <label>Senha:</label>
    <input type="password" name="senha" required>
    <input type="submit" value="Entrar">
</form>
</body>
</html>