<?php
session_start();
include '../config.php';
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

if (isset($_GET['aprovar'])) {
    $id = $_GET['aprovar'];
    $conn->query("UPDATE membros SET aprovado=1 WHERE id=$id");
}
if (isset($_GET['remover'])) {
    $id = $_GET['remover'];
    $conn->query("DELETE FROM membros WHERE id=$id");
}

$membros = $conn->query("SELECT * FROM membros WHERE aprovado=0")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Aprovar Membros</title>
<link rel="stylesheet" href="../css style.css">
</head>
<body>
<h2>Solicitações Pendentes</h2>
<?php foreach($membros as $m): ?>
<div class="card">
    <?php echo $m['nome']." - ".$m['email']; ?>
    <br>
    <a href="?aprovar=<?php echo $m['id']; ?>">✅ Aprovar</a> | 
    <a href="?remover=<?php echo $m['id']; ?>">❌ Remover</a>
</div>
<?php endforeach; ?>
</body>
</html>