<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Painel Admin</title>
<link rel="stylesheet" href="../css style.css">
</head>
<body>
<h2>Bem-vindo, <?php echo $_SESSION['admin']; ?>!</h2>
<nav>
    <a href="aprovar.php">Aprovar Membros</a>
    <a href="gerenciar.php">Gerenciar Conteúdo</a>
    <a href="logout.php">Sair</a>
</nav>
</body>
</html>